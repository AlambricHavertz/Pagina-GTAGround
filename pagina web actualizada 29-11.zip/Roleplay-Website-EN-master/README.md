<h2>Website | English Roleplay-Website</h2>

There is a free website for Roleplay Server here.

The website is my intellectual property, and is misused under the DMCA license.

This website is FREE and will never be sold for money!

Anyone who publishes the website as his or sells it for money will have to take legal measures as a consequence.


<h2> What do I need for the website? </h2>
You need PHP (Developet on 7.3), Apache2 or other webserver.

<h2> How do I set up the website? </h2>
The texts are inserted in the respective .html file.
The individual links are inserted in the .html files as well as in the files <b> contact.php </b> and <b> apply.php </b>

<h2> Is the website updated? </h2>
I wrote the website a long time ago, and of course it is not yet fully developed, let alone with a "clean code".
Therefore I ask you to inform me of any errors, requests or anything else, then I will update the whole thing.

<h2> What is the resolution ?! </h2>
At the moment the website is only for the PC application, the website is not displayed correctly on the mobile phone, depending on the request,
I can set up the whole thing and bring it out as an update.

<h2> Contact us? </h2>
You can ask for support, questions and general information in our Discord https://discord.gg/3gS6BDM

<h3> Pages </h3>
<pre>
- Home page
- About Us page
- Application form
- Contact form
- partner side
- Imprint
</pre>

Kind regards, <br>
Joshua Gerke